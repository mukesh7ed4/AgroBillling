// ================================================
//  src/app/core/services/auth.service.ts
//  REPLACE existing file completely
//
//  Changes:
//  1. refreshSubscriptionStatus() method added — login ke baad bhi
//     server se fresh status fetch kar sakta hai
//  2. isSubscriptionExpiredByDate() helper — date-based check
//  3. setPendingPaymentRequest() — PENDING status support
// ================================================

import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import {
  BehaviorSubject,
  Observable,
  defer,
  interval,
  of,
  tap,
  take,
  map,
  filter,
  defaultIfEmpty,
  catchError
} from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApiResponse } from '../models/models';
import { clearHttpGetCache } from '../interceptors/http-cache.interceptor';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly router       = inject(Router);
  private readonly http         = inject(HttpClient);
  private readonly tokenKey     = 'access_token';
  private readonly roleKey      = 'ab_role';
  private readonly shopIdKey    = 'ab_shop_id';
  private readonly shopNameKey  = 'ab_shop_name';
  private readonly subStatusKey = 'ab_sub_status';
  private readonly subExpiryKey = 'ab_sub_expiry';

  private _shopId$     = new BehaviorSubject<number | null>(this.readShopIdFromLocalStorage());
  private _isLoggedIn$ = new BehaviorSubject<boolean>(this.hasValidToken());

  readonly shopId$     = this._shopId$.asObservable();
  readonly isLoggedIn$ = this._isLoggedIn$.asObservable();

  constructor() {
    this.hydrateShopIdFromJwtIfMissing();
    this._isLoggedIn$.next(this.hasValidToken());
  }

  ensureShopId$(): Observable<number | null> {
    return defer(() => {
      const id = this.getShopId();
      if (id != null) return of(id);
      return interval(20).pipe(
        take(100),
        map(() => this.getShopId()),
        filter((x): x is number => x != null),
        take(1)
      );
    }).pipe(
      take(1),
      defaultIfEmpty(null as number | null),
      map(id => id ?? this.getShopId())
    );
  }

  runWhenShopReady(fn: () => void): void {
    this.ensureShopId$().pipe(take(1)).subscribe(() => fn());
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  hasValidToken(): boolean {
    const t = this.getToken();
    if (!t) return false;
    return !this.isJwtExpired(t);
  }

  // ✅ Check expiry by date (guard use karta hai)
  isSubscriptionExpiredByDate(): boolean {
    const expiry = this.getSubscriptionExpiry();
    if (!expiry) return true;
    const expiryDate = new Date(expiry);
    expiryDate.setHours(23, 59, 59, 999);
    return new Date() > expiryDate;
  }

  // ✅ Days remaining — header warning ke liye
  getDaysUntilExpiry(): number | null {
    const expiry = this.getSubscriptionExpiry();
    if (!expiry) return null;
    const expiryDate = new Date(expiry);
    expiryDate.setHours(23, 59, 59, 999);
    const diff = expiryDate.getTime() - new Date().getTime();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  }

  // ✅ SIGNUP
  signup(body: any): Observable<ApiResponse<any>> {
    return this.http
      .post<ApiResponse<any>>(`${environment.apiUrl}/auth/signup`, body)
      .pipe(
        tap(res => {
          const data = res.data as any;
          const token = data?.token || data?.access_token;
          if (token) {
            localStorage.setItem(this.tokenKey, token);
            this._isLoggedIn$.next(true);
          }
          const shopId = data?.shopId;
          if (shopId) {
            localStorage.setItem(this.shopIdKey, shopId.toString());
            this._shopId$.next(shopId);
          }
          const shopName = data?.shopName;
          if (shopName) localStorage.setItem(this.shopNameKey, shopName);
          if (data?.subscriptionStatus) {
            this.setSubscriptionStatus(data.subscriptionStatus, data.subscriptionExpiry);
          }
        })
      );
  }

  // ✅ FIXED LOGIN
  login(body: { email: string; password: string }): Observable<ApiResponse<any>> {
    return this.http
      .post<ApiResponse<any>>(`${environment.apiUrl}/auth/login`, body)
      .pipe(
        tap(res => {
          const data  = res.data;
          const token = data?.token;

          if (token) {
            localStorage.setItem(this.tokenKey, token);
            const payload = this.decodeJwtPayload(token);
            const longClaimRole = payload?.['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
            const role = String(
              payload?.['role'] ?? payload?.['Role'] ?? longClaimRole ?? ''
            ).toUpperCase();
            localStorage.setItem(this.roleKey, role);
          }

          const sid = data?.shopId;
          if (sid != null) {
            localStorage.setItem(this.shopIdKey, String(sid));
            this._shopId$.next(sid);
          } else if (token) {
            const fromJwt = this.parseShopIdFromPayload(this.decodeJwtPayload(token));
            if (fromJwt != null) {
              localStorage.setItem(this.shopIdKey, String(fromJwt));
              this._shopId$.next(fromJwt);
            }
          }

          if (data?.shopName) localStorage.setItem(this.shopNameKey, data.shopName);

          // ✅ Login pe fresh subscription status server se aata hai — save karo
          if (data?.subscriptionStatus) {
            this.setSubscriptionStatus(data.subscriptionStatus, data.subscriptionExpiry);
          }

          this._isLoggedIn$.next(this.hasValidToken());
        })
      );
  }

  // ✅ NEW: Server se fresh subscription status fetch karo
  // Call this when: app starts + after payment submission
  refreshSubscriptionStatus(): Observable<boolean> {
    const shopId = this.getShopId();
    if (!shopId || !this.hasValidToken()) return of(false);

    return this.http
      .get<ApiResponse<any>>(`${environment.apiUrl}/payments/shop-status`)
      .pipe(
        tap(res => {
          // Payment status check — agar PENDING hai toh mark karo
          if (res.data?.status === 'PENDING') {
            this.setSubscriptionStatus('PENDING', this.getSubscriptionExpiry() ?? undefined);
          }
        }),
        map(() => true),
        catchError(() => of(false))
      );
  }

  // ✅ Payment submit hone ke baad PENDING status set karo
  setPendingPaymentStatus(): void {
    this.setSubscriptionStatus('PENDING', this.getSubscriptionExpiry() ?? undefined);
  }

  private isJwtExpired(token: string): boolean {
    const payload = this.decodeJwtPayload(token);
    if (!payload) return true;
    const exp = payload['exp'];
    if (exp == null) return false;
    const e = typeof exp === 'number' ? exp : Number(exp);
    if (!Number.isFinite(e)) return false;
    return e * 1000 < Date.now();
  }

  private decodeJwtPayload(token: string): Record<string, unknown> | null {
    try {
      const part = token.split('.')[1];
      if (!part) return null;
      const base64 = part.replace(/-/g, '+').replace(/_/g, '/');
      const padded  = base64.padEnd(base64.length + (4 - (base64.length % 4)) % 4, '=');
      return JSON.parse(atob(padded)) as Record<string, unknown>;
    } catch {
      return null;
    }
  }

  private jwtPayload(): Record<string, unknown> | null {
    const t = this.getToken();
    if (!t) return null;
    return this.decodeJwtPayload(t);
  }

  isAdmin(): boolean {
    const r = localStorage.getItem(this.roleKey);
    if (r === 'ADMIN' || r === 'admin') return true;
    const p = this.jwtPayload();
    const longClaimRole = p?.['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
    const role = String(p?.['role'] ?? p?.['Role'] ?? longClaimRole ?? '').toUpperCase();
    return role === 'ADMIN';
  }

  isShop(): boolean {
    if (this.isAdmin()) return false;
    const r = localStorage.getItem(this.roleKey);
    if (r === 'SHOP' || r === 'shop') return true;
    const p = this.jwtPayload();
    const longClaimRole = p?.['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
    const role = String(p?.['role'] ?? p?.['Role'] ?? longClaimRole ?? '').toUpperCase();
    if (role === 'SHOP') return true;
    return this.getShopId() != null && this.hasValidToken();
  }

  private readShopIdFromLocalStorage(): number | null {
    const v = localStorage.getItem(this.shopIdKey);
    if (v == null || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }

  private parseShopIdFromPayload(p: Record<string, unknown> | null): number | null {
    if (!p) return null;
    const id = p['shopId'] ?? p['ShopId'] ?? p['shop_id'];
    if (id == null) return null;
    const n = Number(id);
    return Number.isFinite(n) ? n : null;
  }

  private hydrateShopIdFromJwtIfMissing(): void {
    if (this._shopId$.value != null) return;
    const fromLs = this.readShopIdFromLocalStorage();
    if (fromLs != null) { this._shopId$.next(fromLs); return; }
    const sid = this.parseShopIdFromPayload(this.jwtPayload());
    if (sid != null) {
      localStorage.setItem(this.shopIdKey, String(sid));
      this._shopId$.next(sid);
    }
  }

  getShopId(): number | null {
    const subj = this._shopId$.value;
    if (subj != null) return subj;
    const fromLs = this.readShopIdFromLocalStorage();
    if (fromLs != null) { this._shopId$.next(fromLs); return fromLs; }
    const p = this.jwtPayload();
    const n = this.parseShopIdFromPayload(p);
    if (n != null) {
      localStorage.setItem(this.shopIdKey, String(n));
      this._shopId$.next(n);
    }
    return n;
  }

  getSubscriptionStatus(): 'ACTIVE' | 'TRIAL' | 'EXPIRED' | 'PENDING' | null {
    return localStorage.getItem(this.subStatusKey) as any;
  }

  getSubscriptionExpiry(): string | null {
    return localStorage.getItem(this.subExpiryKey);
  }

  setSubscriptionStatus(status: string, expiry?: string): void {
    localStorage.setItem(this.subStatusKey, status);
    if (expiry) localStorage.setItem(this.subExpiryKey, expiry);
  }

  getShopName(): string | null {
    const n = localStorage.getItem(this.shopNameKey);
    if (n) return n;
    const p = this.jwtPayload();
    const name = p?.['shopName'] ?? p?.['ShopName'];
    return name != null ? String(name) : null;
  }

  logout(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.roleKey);
    localStorage.removeItem(this.shopIdKey);
    localStorage.removeItem(this.shopNameKey);
    localStorage.removeItem(this.subStatusKey);
    localStorage.removeItem(this.subExpiryKey);
    clearHttpGetCache();
    this._shopId$.next(null);
    this._isLoggedIn$.next(false);
    this.router.navigate(['/auth/login']);
  }
}