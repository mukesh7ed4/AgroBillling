// ================================================
//  src/app/core/guards/auth.guard.ts
//  REPLACE existing file completely
//
//  Fix: subscriptionGuard ab actual expiry DATE check karta hai
//  localStorage ka stale status nahi — real date compare karta hai
// ================================================

import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { take, map } from 'rxjs';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = () => {
  const auth   = inject(AuthService);
  const router = inject(Router);
  if (auth.hasValidToken()) return true;
  router.navigate(['/auth/login']);
  return false;
};

export const adminGuard: CanActivateFn = () => {
  const auth   = inject(AuthService);
  const router = inject(Router);
  if (auth.hasValidToken() && auth.isAdmin()) return true;
  if (auth.hasValidToken()) router.navigate(['/shop/dashboard']);
  else router.navigate(['/auth/login']);
  return false;
};

export const shopGuard: CanActivateFn = () => {
  const auth   = inject(AuthService);
  const router = inject(Router);

  if (!auth.hasValidToken()) {
    router.navigate(['/auth/login']);
    return false;
  }

  if (!auth.isShop()) {
    router.navigate(['/admin/dashboard']);
    return false;
  }

  if (auth.getShopId() != null) return true;

  return auth.ensureShopId$().pipe(
    take(1),
    map(id => {
      if (id != null) return true;
      router.navigate(['/auth/login']);
      return false;
    })
  );
};

// ✅ FIXED: subscriptionGuard
// Sirf localStorage status pe rely nahi karta.
// Actual expiry DATE check karta hai — stale localStorage se protect karta hai.
// Agar status TRIAL/ACTIVE hai BUT expiry date past mein hai → /subscribe bhejta hai
export const subscriptionGuard: CanActivateFn = () => {
  const auth   = inject(AuthService);
  const router = inject(Router);

  // shopGuard pehle se token check karta hai — yahan sirf subscription check karo
  if (!auth.hasValidToken()) return true;

  const status = auth.getSubscriptionStatus();
  const expiry = auth.getSubscriptionExpiry(); // "yyyy-MM-dd" string

  // Koi status nahi — subscribe pe bhejo
  if (!status) {
    router.navigate(['/subscribe']);
    return false;
  }

  // EXPIRED status — sidha bhejo
  if (status === 'EXPIRED') {
    router.navigate(['/subscribe']);
    return false;
  }

  // ACTIVE ya TRIAL — lekin expiry date bhi check karo
  if (status === 'ACTIVE' || status === 'TRIAL') {
    if (expiry) {
      const expiryDate = new Date(expiry);
      expiryDate.setHours(23, 59, 59, 999); // din ke end tak valid
      const now = new Date();

      if (now > expiryDate) {
        // Expiry past mein — status update karo aur subscribe bhejo
        auth.setSubscriptionStatus('EXPIRED', expiry);
        router.navigate(['/subscribe']);
        return false;
      }
    }
    return true;
  }

  // PENDING status (payment submitted, admin ne approve nahi kiya)
  // Subscribe page pe hi raho — wahan pending state dikhega
  if (status === 'PENDING') {
    router.navigate(['/subscribe']);
    return false;
  }

  router.navigate(['/subscribe']);
  return false;
};