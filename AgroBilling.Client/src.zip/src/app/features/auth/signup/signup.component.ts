import { Component, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ThemeService } from '../../../core/services/theme.service';
import { AuthService } from '../../../core/services/auth.service';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, FormsModule],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent {
  private fb   = inject(FormBuilder);
  private cdr  = inject(ChangeDetectorRef);
  private http = inject(HttpClient);

  // ── State ───────────────────────────────────────────────────
  step: 'form' | 'otp' = 'form';

  // Form step
  submitting = false;
  error      = '';
  year       = new Date().getFullYear();

  // OTP step
  signupEmail = '';
  otpValue    = '';
  otpError    = '';
  verifying   = false;
  resending   = false;
  resendMsg   = '';

  form = this.fb.group({
    shopName:     ['', Validators.required],
    ownerName:    ['', Validators.required],
    mobileNumber: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
    email:        ['', [Validators.required, Validators.email]],
    city:         ['', Validators.required],
    state:        ['Haryana'],
    password:     ['', [Validators.required, Validators.minLength(6)]],
    confirmPass:  ['', Validators.required]
  }, { validators: this.passwordMatch });

  constructor(
    public  theme: ThemeService,
    private auth:  AuthService,
    private router: Router
  ) {}

  private passwordMatch(g: any) {
    const p  = g.get('password')?.value;
    const cp = g.get('confirmPass')?.value;
    return p === cp ? null : { mismatch: true };
  }

  // ── Step 1: Submit signup form ──────────────────────────────
  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }

    const { confirmPass, ...payload } = this.form.value;
    this.submitting = true;
    this.error      = '';

    this.auth.signup(payload).subscribe({
      next: (res: any) => {
        this.submitting  = false;
        this.signupEmail = payload.email!;
        this.step        = 'otp';   // ✅ Move to OTP step
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        this.submitting = false;
        this.error = err.error?.message || 'Signup failed. Please try again.';
        this.cdr.detectChanges();
      }
    });
  }

  // ── Step 2: Verify OTP ──────────────────────────────────────
  verifyOtp(): void {
    if (!this.otpValue || this.otpValue.length !== 6) return;
    this.verifying = true;
    this.otpError  = '';

    this.http.post<any>(`${environment.apiUrl}/auth/verify-otp`, {
      email: this.signupEmail,
      otp:   this.otpValue
    }).subscribe({
      next: (res: any) => {
        const d = res?.data;

        // ✅ Save token + shop info (same as login)
        if (d?.token) {
          localStorage.setItem('access_token', d.token);
          localStorage.setItem('ab_role',      'SHOP');
          localStorage.setItem('ab_shop_id',   d.shopId?.toString() ?? '');
          localStorage.setItem('ab_shop_name', d.shopName ?? '');
        }
        if (d?.subscriptionStatus) {
          this.auth.setSubscriptionStatus(d.subscriptionStatus, d.subscriptionExpiry);
        } else {
          this.auth.setSubscriptionStatus('TRIAL');
        }

        this.router.navigate(['/shop/dashboard']);
      },
      error: (err: any) => {
        this.verifying = false;
        this.otpError  = err.error?.message || 'Invalid OTP. Please try again.';
        this.cdr.detectChanges();
      }
    });
  }

  // ── Resend OTP ──────────────────────────────────────────────
  resendOtp(): void {
    this.resending = true;
    this.resendMsg = '';
    this.otpError  = '';

    this.http.post<any>(`${environment.apiUrl}/auth/resend-otp`, {
      email: this.signupEmail
    }).subscribe({
      next: () => {
        this.resending = false;
        this.resendMsg = '✅ New OTP sent!';
        this.otpValue  = '';
        this.cdr.detectChanges();
      },
      error: () => {
        this.resending = false;
        this.otpError  = 'Could not resend OTP. Please try again.';
        this.cdr.detectChanges();
      }
    });
  }

  get f() { return this.form.controls; }
}