import { TestBed } from '@angular/core/testing';
import { App } from './app';

// Vitest uses global imports, but you need to import them
import { describe, it, expect, beforeEach } from 'vitest';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should render title', async () => {
    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();
    const compiled = fixture.nativeElement as HTMLElement;
    // Update this based on your actual app component
    expect(compiled.querySelector('h1')?.textContent).toContain('Hello, AgroBilling.Client');
  });
});