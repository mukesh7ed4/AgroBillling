// ================================================
//  AgroBillling.API / Controllers / AuthController.cs
//  ✅ With Email OTP Verification
// ================================================

using AgroBillling.DAL.Context;
using AgroBillling.DAL.Models;
using AgroBillling.DAL.Repositories.Interfaces;
using AgroBilling.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace AgroBillling.API.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthRepository _authRepo;
        private readonly IConfiguration _config;
        private readonly AgroBillingDbContext _context;
        private readonly EmailService _emailService;

        public AuthController(
            IAuthRepository authRepo,
            IConfiguration config,
            AgroBillingDbContext context,
            EmailService emailService)
        {
            _authRepo = authRepo;
            _config = config;
            _context = context;
            _emailService = emailService;
        }

        // ===========================
        // ✅ SIGNUP — sends OTP
        // ===========================
        [HttpPost("signup")]
        [AllowAnonymous]
        public async Task<IActionResult> Signup([FromBody] SignupDto dto)
        {
            try
            {
                if (dto == null || string.IsNullOrWhiteSpace(dto.Email) || string.IsNullOrWhiteSpace(dto.Password))
                    return BadRequest(ApiResponse<string>.Fail("All required fields must be provided"));

                var existing = await _context.Shops.FirstOrDefaultAsync(s => s.Email == dto.Email);
                if (existing != null)
                    return BadRequest(ApiResponse<string>.Fail("Email already registered"));

                var adminId = await _context.AdminUsers
                    .Where(a => a.IsActive == true)
                    .Select(a => a.AdminId)
                    .FirstOrDefaultAsync();

                if (adminId == 0)
                    return StatusCode(500, ApiResponse<string>.Fail("System not configured. No admin found."));

                var passwordHash = HashPassword(dto.Password);

                // ✅ Generate OTP
                var otp = new Random().Next(100000, 999999).ToString();
                var otpExpiry = DateTime.UtcNow.AddMinutes(10);

                var shop = new Shop
                {
                    OwnerName = dto.OwnerName ?? "Shop Owner",
                    ShopName = dto.ShopName ?? "My Shop",
                    MobileNumber = dto.MobileNumber ?? "0000000000",
                    Email = dto.Email,
                    Address = dto.City ?? "N/A",
                    City = dto.City ?? "N/A",
                    State = dto.State ?? "Haryana",
                    PinCode = "000000",
                    Gstpercent = 18,
                    BillStartNumber = 1,
                    CurrentBillSequence = 0,
                    PasswordHash = passwordHash,
                    IsActive = false,           // ✅ inactive until verified
                    IsEmailVerified = false,
                    EmailOtp = otp,
                    OtpExpiresAt = otpExpiry,
                    CreatedAt = DateTime.UtcNow,
                    CreatedByAdminId = adminId
                };

                _context.Shops.Add(shop);
                await _context.SaveChangesAsync();

                // Trial subscription (will activate after OTP verify)
                var trialPlan = await _context.SubscriptionPlans
                    .FirstOrDefaultAsync(p => p.IsTrial == true);

                var today = DateOnly.FromDateTime(DateTime.UtcNow);
                var trialDays = trialPlan?.DurationDays ?? 14;

                _context.ShopSubscriptions.Add(new ShopSubscription
                {
                    ShopId = shop.ShopId,
                    PlanId = trialPlan?.PlanId ?? 1,
                    StartDate = today,
                    EndDate = today.AddDays(trialDays),
                    AmountPaid = 0,
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow
                });

                await _context.SaveChangesAsync();

                // ✅ Send OTP email
                await _emailService.SendOtpAsync(shop.Email, shop.ShopName, otp);

                return Ok(ApiResponse<object>.Ok(new
                {
                    email = shop.Email,
                    shopId = shop.ShopId,
                    message = "OTP sent to your email"
                }, "OTP sent. Please verify your email."));
            }
            catch (Exception ex)
            {
                return StatusCode(500, ApiResponse<string>.Fail(
                    $"Signup failed: {ex.Message} | {ex.InnerException?.Message}"));
            }
        }

        // ===========================
        // ✅ VERIFY OTP
        // ===========================
        [HttpPost("verify-otp")]
        [AllowAnonymous]
        public async Task<IActionResult> VerifyOtp([FromBody] VerifyOtpDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Email) || string.IsNullOrWhiteSpace(dto.Otp))
                return BadRequest(ApiResponse<string>.Fail("Email and OTP are required"));

            var shop = await _context.Shops
                .FirstOrDefaultAsync(s => s.Email == dto.Email);

            if (shop == null)
                return BadRequest(ApiResponse<string>.Fail("Shop not found"));

            if (shop.IsEmailVerified)
                return BadRequest(ApiResponse<string>.Fail("Email already verified. Please login."));

            if (shop.EmailOtp != dto.Otp)
                return BadRequest(ApiResponse<string>.Fail("Invalid OTP. Please check your email."));

            if (shop.OtpExpiresAt < DateTime.UtcNow)
                return BadRequest(ApiResponse<string>.Fail("OTP expired. Please signup again."));

            // ✅ Activate account
            shop.IsEmailVerified = true;
            shop.IsActive = true;
            shop.EmailOtp = null;
            shop.OtpExpiresAt = null;
            await _context.SaveChangesAsync();

            // Admin notification
            _context.AdminNotifications.Add(new AdminNotification
            {
                ShopId = shop.ShopId,
                NotificationType = "NEW_SIGNUP",
                Message = $"New verified signup: {shop.ShopName} ({shop.OwnerName}) - {shop.MobileNumber}",
                IsRead = false,
                CreatedAt = DateTime.UtcNow
            });
            await _context.SaveChangesAsync();

            // Get subscription info
            var sub = await _context.ShopSubscriptions
                .Include(s => s.Plan)
                .FirstOrDefaultAsync(s => s.ShopId == shop.ShopId && s.IsActive);

            var today = DateOnly.FromDateTime(DateTime.UtcNow);
            var status = sub != null && sub.EndDate >= today
                ? (sub.Plan?.IsTrial == true ? "TRIAL" : "ACTIVE")
                : "EXPIRED";
            var expiry = sub?.EndDate.ToString("yyyy-MM-dd") ?? "";

            // ✅ Auto-login after verify
            var token = GenerateToken(shop.ShopId.ToString(), "SHOP", shop.ShopId, shop.ShopName);

            return Ok(ApiResponse<object>.Ok(new
            {
                token,
                role = "SHOP",
                shopId = shop.ShopId,
                shopName = shop.ShopName,
                ownerName = shop.OwnerName,
                subscriptionStatus = status,
                subscriptionExpiry = expiry
            }, "Email verified! Welcome to AgroBilling."));
        }

        // ===========================
        // ✅ RESEND OTP
        // ===========================
        [HttpPost("resend-otp")]
        [AllowAnonymous]
        public async Task<IActionResult> ResendOtp([FromBody] ResendOtpDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Email))
                return BadRequest(ApiResponse<string>.Fail("Email required"));

            var shop = await _context.Shops
                .FirstOrDefaultAsync(s => s.Email == dto.Email && s.IsEmailVerified == false);

            if (shop == null)
                return BadRequest(ApiResponse<string>.Fail("Email not found or already verified"));

            var otp = new Random().Next(100000, 999999).ToString();
            shop.EmailOtp = otp;
            shop.OtpExpiresAt = DateTime.UtcNow.AddMinutes(10);
            await _context.SaveChangesAsync();

            await _emailService.SendOtpAsync(shop.Email, shop.ShopName, otp);

            return Ok(ApiResponse<string>.Ok("ok", "OTP resent successfully"));
        }

        // ===========================
        // ✅ LOGIN
        // ===========================
        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.Email) || string.IsNullOrWhiteSpace(dto.Password))
                return BadRequest(ApiResponse<string>.Fail("Email and password are required."));

            // Admin check
            var admin = await _authRepo.ValidateAdminAsync(dto.Email, dto.Password);
            if (admin != null)
            {
                var token = GenerateToken(admin.AdminId.ToString(), "ADMIN", null, null);
                return Ok(ApiResponse<AuthResponseDto>.Ok(new AuthResponseDto
                {
                    Token = token,
                    RefreshToken = Guid.NewGuid().ToString(),
                    Role = "ADMIN",
                    OwnerName = admin.FullName,
                    ExpiresAt = DateTime.UtcNow.AddDays(7)
                }));
            }

            // Shop check
            var shop = await _authRepo.ValidateShopAsync(dto.Email, dto.Password);
            if (shop != null)
            {
                // ✅ Check if email verified
                if (!shop.IsEmailVerified)
                    return Unauthorized(ApiResponse<string>.Fail(
                        "Email not verified. Please check your email for OTP."));

                var sub = await _context.ShopSubscriptions
                    .Include(s => s.Plan)
                    .FirstOrDefaultAsync(s => s.ShopId == shop.ShopId && s.IsActive);

                var today = DateOnly.FromDateTime(DateTime.Now);
                var status = "EXPIRED";
                var expiry = "";

                if (sub != null)
                {
                    if (sub.EndDate >= today)
                        status = sub.Plan?.IsTrial == true ? "TRIAL" : "ACTIVE";
                    expiry = sub.EndDate.ToString("yyyy-MM-dd");
                }

                var token = GenerateToken(shop.ShopId.ToString(), "SHOP", shop.ShopId, shop.ShopName);

                return Ok(ApiResponse<AuthResponseDto>.Ok(new AuthResponseDto
                {
                    Token = token,
                    RefreshToken = Guid.NewGuid().ToString(),
                    Role = "SHOP",
                    ShopId = shop.ShopId,
                    ShopName = shop.ShopName,
                    OwnerName = shop.OwnerName,
                    SubscriptionStatus = status,
                    SubscriptionExpiry = expiry,
                    ExpiresAt = DateTime.UtcNow.AddDays(7)
                }));
            }

            return Unauthorized(ApiResponse<string>.Fail("Invalid email or password"));
        }

        // ===========================
        // ✅ JWT TOKEN
        // ===========================
        private string GenerateToken(string userId, string role, int? shopId, string? shopName)
        {
            var jwtKey = _config["Jwt:Key"];
            if (string.IsNullOrEmpty(jwtKey))
                throw new InvalidOperationException("Jwt:Key missing");

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new(JwtRegisteredClaimNames.Sub, userId),
                new Claim("role", role),
                new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            if (shopId.HasValue) claims.Add(new Claim("shopId", shopId.Value.ToString()));
            if (!string.IsNullOrEmpty(shopName)) claims.Add(new Claim("shopName", shopName));

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddDays(7),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private static string HashPassword(string password)
        {
            using var sha = System.Security.Cryptography.SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
            return Convert.ToHexString(bytes).ToLower();
        }
    }
}